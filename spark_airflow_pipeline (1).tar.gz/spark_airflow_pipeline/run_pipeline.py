#!/usr/bin/env python3
"""Run the whole pipeline locally, without Airflow.

This executes the same tasks, in the same order, as dags/sales_pipeline_dag.py,
so it doubles as a dev loop, a backfill tool, and a target for plain cron.

  python run_pipeline.py --ds 2026-10-01
  python run_pipeline.py --start 2026-10-01 --end 2026-10-07        # backfill, oldest first
  python run_pipeline.py --ds 2026-10-01 --tasks ingest transform   # a subset

cron example (daily at 02:00, yesterday's partition):
  0 2 * * * cd /path/to/spark_airflow_pipeline && python run_pipeline.py --ds $(date -d yesterday +\\%F)
"""
from __future__ import annotations

import argparse
import sys
import time
from datetime import date, timedelta

from jobs import export_report, generate_data, ingest, quality_check, transform
from pipeline.config import Paths, validate_ds

# Ordered exactly like the Airflow dependency chain.
TASKS = {
    "generate_data": generate_data.run,
    "ingest": ingest.run,
    "transform": transform.run,
    "quality_check": quality_check.run,
    "export_report": export_report.run,
}


def date_range(start: str, end: str) -> list[str]:
    d0, d1 = date.fromisoformat(validate_ds(start)), date.fromisoformat(validate_ds(end))
    if d1 < d0:
        raise ValueError("--end must not be before --start")
    return [(d0 + timedelta(days=i)).isoformat() for i in range((d1 - d0).days + 1)]


def run_for_date(ds: str, paths: Paths, selected: list[str]) -> None:
    print(f"\n=== ds={ds} " + "=" * 50)
    for name in TASKS:
        if name not in selected:
            continue
        started = time.time()
        TASKS[name](ds, paths)
        print(f"--- {name} finished in {time.time() - started:.1f}s")


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the sales pipeline locally")
    parser.add_argument("--ds", help="single run date, YYYY-MM-DD")
    parser.add_argument("--start", help="backfill start date")
    parser.add_argument("--end", help="backfill end date (inclusive)")
    parser.add_argument("--tasks", nargs="+", choices=list(TASKS), default=list(TASKS))
    parser.add_argument("--data-dir", default=None)
    args = parser.parse_args()

    if args.ds and (args.start or args.end):
        parser.error("use either --ds or --start/--end, not both")
    if args.ds:
        dates = [validate_ds(args.ds)]
    elif args.start and args.end:
        dates = date_range(args.start, args.end)
    else:
        parser.error("provide --ds, or both --start and --end")

    paths = Paths(args.data_dir)
    for ds in dates:
        run_for_date(ds, paths, args.tasks)
    print(f"\nDone: {len(dates)} run date(s) under {paths.base}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
