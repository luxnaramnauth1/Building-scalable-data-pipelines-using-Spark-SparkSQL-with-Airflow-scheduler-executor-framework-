"""Spark session factory and SparkSQL file helpers."""
from __future__ import annotations

import os
from pathlib import Path
from string import Template

from pyspark.sql import DataFrame, SparkSession

from pipeline.config import SQL_DIR, validate_ds


def get_spark(app_name: str = "sales_pipeline") -> SparkSession:
    """Create (or reuse) a SparkSession.

    Settings come from environment variables so the same code runs under
    ``python``, ``spark-submit`` and Airflow:

    SPARK_MASTER              default ``local[2]``
    SPARK_SHUFFLE_PARTITIONS  default ``4`` (the Spark default of 200 is wasteful for small data)
    """
    spark = (
        SparkSession.builder.appName(app_name)
        .master(os.environ.get("SPARK_MASTER", "local[2]"))
        .config("spark.sql.shuffle.partitions", os.environ.get("SPARK_SHUFFLE_PARTITIONS", "4"))
        # Only overwrite the ds partitions being written -> idempotent re-runs and backfills.
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
        .config("spark.sql.session.timeZone", "UTC")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    return spark


def render_sql(sql_file: str | Path, **params: str) -> str:
    """Load a .sql file and substitute ``${name}`` placeholders.

    ``ds`` is validated because it is spliced into the query text.
    """
    path = Path(sql_file)
    if not path.is_absolute():
        path = SQL_DIR / path
    if "ds" in params:
        validate_ds(params["ds"])
    return Template(path.read_text(encoding="utf-8")).substitute(params)


def run_sql_file(spark: SparkSession, sql_file: str | Path, **params: str) -> DataFrame:
    """Render a single-statement SQL file and execute it."""
    return spark.sql(render_sql(sql_file, **params))


def read_partition(spark: SparkSession, path: Path, ds: str, *, up_to: bool = False) -> DataFrame:
    """Read a ds-partitioned parquet table for one ds (or every ds <= ds when up_to=True)."""
    validate_ds(ds)
    df = spark.read.parquet(str(path))
    return df.where(f"ds <= '{ds}'") if up_to else df.where(f"ds = '{ds}'")


def write_partition(df: DataFrame, path: Path) -> None:
    """Write ``df`` as parquet partitioned by its ``ds`` column (dynamic overwrite)."""
    df.write.mode("overwrite").partitionBy("ds").parquet(str(path))
