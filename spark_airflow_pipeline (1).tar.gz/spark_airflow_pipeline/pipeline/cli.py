"""Tiny CLI helper shared by every job so they all accept the same flags."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def ensure_project_on_path() -> None:
    """Make ``import pipeline`` work when a job file is run directly (e.g. by spark-submit)."""
    root = str(Path(__file__).resolve().parents[1])
    if root not in sys.path:
        sys.path.insert(0, root)


def job_parser(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--ds", required=True, help="Run date, YYYY-MM-DD (Airflow: {{ ds }})")
    parser.add_argument(
        "--data-dir",
        default=None,
        help="Data lake root (default: $PIPELINE_DATA_DIR or ./data)",
    )
    return parser
