"""Shared helpers for the sales data pipeline."""
