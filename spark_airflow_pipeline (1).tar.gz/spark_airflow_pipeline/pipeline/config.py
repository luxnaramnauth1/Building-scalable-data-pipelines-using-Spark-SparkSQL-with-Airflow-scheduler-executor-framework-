"""Central configuration: where data lives and how the lake is laid out.

Layout (medallion style), everything partitioned by the run date ``ds``:

    data/raw/<entity>/ds=YYYY-MM-DD/<entity>.csv      landing files (generate_data)
    data/bronze/<entity>/ds=YYYY-MM-DD/*.parquet      raw strings + lineage columns (ingest)
    data/silver/<table>/ds=YYYY-MM-DD/*.parquet       typed, cleaned, deduplicated (transform)
    data/gold/<table>/ds=YYYY-MM-DD/*.parquet         business aggregates (transform)
    data/quality/ds=YYYY-MM-DD/results.json           data-quality results (quality_check)
    data/reports/ds=YYYY-MM-DD/*.csv                  exported reports (export_report)

Override the root with the PIPELINE_DATA_DIR environment variable.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SQL_DIR = PROJECT_ROOT / "sql"

ENTITIES = ("customers", "products", "orders")

_DS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def validate_ds(ds: str) -> str:
    """Return ``ds`` if it is a YYYY-MM-DD string, otherwise raise ValueError.

    ds is interpolated into SQL and file paths, so it is validated strictly.
    """
    if not isinstance(ds, str) or not _DS_RE.match(ds):
        raise ValueError(f"ds must look like YYYY-MM-DD, got {ds!r}")
    return ds


class Paths:
    """Resolves every location the pipeline reads or writes."""

    def __init__(self, base_dir: str | os.PathLike | None = None):
        base = base_dir or os.environ.get("PIPELINE_DATA_DIR") or PROJECT_ROOT / "data"
        self.base = Path(base).resolve()

    def raw_dir(self, entity: str, ds: str) -> Path:
        return self.base / "raw" / entity / f"ds={validate_ds(ds)}"

    def raw_file(self, entity: str, ds: str) -> Path:
        return self.raw_dir(entity, ds) / f"{entity}.csv"

    def bronze(self, entity: str) -> Path:
        return self.base / "bronze" / entity

    def silver(self, table: str) -> Path:
        return self.base / "silver" / table

    def gold(self, table: str) -> Path:
        return self.base / "gold" / table

    def layer(self, layer: str, table: str) -> Path:
        return self.base / layer / table

    def quality_dir(self, ds: str) -> Path:
        return self.base / "quality" / f"ds={validate_ds(ds)}"

    def reports_dir(self, ds: str) -> Path:
        return self.base / "reports" / f"ds={validate_ds(ds)}"
