-- Gold: customer lifetime value as of this run date.
-- Reads every silver_orders_clean partition up to and including ds, so a backfill
-- over several days produces correct cumulative numbers for each day.
WITH completed AS (
    SELECT * FROM silver_orders_clean_all WHERE status = 'completed'
),
per_customer AS (
    SELECT
        customer_id,
        count(*)                          AS lifetime_orders,
        sum(revenue)                      AS lifetime_revenue,
        min(order_date)                   AS first_order_date,
        max(order_date)                   AS last_order_date
    FROM completed
    GROUP BY customer_id
)
SELECT
    pc.customer_id,
    c.name,
    c.country,
    pc.lifetime_orders,
    CAST(pc.lifetime_revenue AS DECIMAL(14,2))                         AS lifetime_revenue,
    CAST(pc.lifetime_revenue / pc.lifetime_orders AS DECIMAL(12,2))    AS avg_order_value,
    pc.first_order_date,
    pc.last_order_date,
    CASE
        WHEN pc.lifetime_revenue >= 1000 THEN 'gold'
        WHEN pc.lifetime_revenue >= 400  THEN 'silver'
        ELSE 'bronze'
    END                                                                AS ltv_tier,
    dense_rank() OVER (ORDER BY pc.lifetime_revenue DESC)              AS revenue_rank,
    '${ds}'                                                            AS ds
FROM per_customer pc
JOIN silver_customers c ON c.customer_id = pc.customer_id
