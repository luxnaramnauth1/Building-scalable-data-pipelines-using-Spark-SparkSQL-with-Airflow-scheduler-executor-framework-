-- Silver: typed customers (one snapshot per ds).
SELECT
    try_cast(trim(customer_id) AS INT)  AS customer_id,
    trim(name)                          AS name,
    lower(trim(email))                  AS email,
    upper(trim(country))                AS country,
    try_cast(trim(signup_date) AS DATE) AS signup_date,
    '${ds}'                             AS ds
FROM bronze_customers
WHERE try_cast(trim(customer_id) AS INT) IS NOT NULL
