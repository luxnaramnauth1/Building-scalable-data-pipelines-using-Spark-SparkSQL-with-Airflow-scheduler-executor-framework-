-- Silver: valid, deduplicated orders enriched with product and customer attributes.
SELECT
    s.order_id,
    s.customer_id,
    s.product_id,
    s.quantity,
    s.order_ts,
    CAST(s.order_ts AS DATE)                  AS order_date,
    s.status,
    p.category,
    p.unit_price,
    CAST(s.quantity * p.unit_price AS DECIMAL(12,2)) AS revenue,
    c.country,
    '${ds}'                                   AS ds
FROM stg_orders_checked s
JOIN silver_products  p ON p.product_id  = s.product_id
JOIN silver_customers c ON c.customer_id = s.customer_id
WHERE s.reject_reason IS NULL
