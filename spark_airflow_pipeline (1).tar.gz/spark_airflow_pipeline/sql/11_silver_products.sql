-- Silver: typed products (one snapshot per ds).
SELECT
    try_cast(trim(product_id) AS INT)          AS product_id,
    trim(product_name)                         AS product_name,
    lower(trim(category))                      AS category,
    try_cast(trim(unit_price) AS DECIMAL(10,2)) AS unit_price,
    '${ds}'                                    AS ds
FROM bronze_products
WHERE try_cast(trim(product_id) AS INT) IS NOT NULL
  AND try_cast(trim(unit_price) AS DECIMAL(10,2)) IS NOT NULL
