-- Silver: quarantine table. Every rejected order with the reason, for review and replay.
SELECT
    order_id,
    customer_id,
    product_id,
    raw_quantity,
    order_ts,
    status,
    reject_reason,
    source_file,
    '${ds}' AS ds
FROM stg_orders_checked
WHERE reject_reason IS NOT NULL
