-- Gold: daily sales by category and country for the orders loaded in this run.
-- Revenue only counts completed orders; cancelled and refunded orders are tracked separately.
SELECT
    order_date,
    category,
    country,
    count(*)                                                            AS orders,
    sum(quantity)                                                       AS units,
    CAST(sum(CASE WHEN status = 'completed' THEN revenue ELSE 0 END) AS DECIMAL(14,2))
                                                                        AS completed_revenue,
    CAST(sum(revenue) AS DECIMAL(14,2))                                 AS gross_revenue,
    sum(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END)               AS cancelled_orders,
    sum(CASE WHEN status = 'refunded'  THEN 1 ELSE 0 END)               AS refunded_orders,
    '${ds}'                                                             AS ds
FROM silver_orders_clean
GROUP BY order_date, category, country
