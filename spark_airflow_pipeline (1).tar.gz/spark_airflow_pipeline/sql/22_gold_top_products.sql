-- Gold: top 3 products by completed revenue within each category, for this run's orders.
WITH product_revenue AS (
    SELECT
        o.category,
        o.product_id,
        p.product_name,
        sum(o.quantity)                                        AS units_sold,
        CAST(sum(o.revenue) AS DECIMAL(14,2))                  AS completed_revenue
    FROM silver_orders_clean o
    JOIN silver_products p ON p.product_id = o.product_id
    WHERE o.status = 'completed'
    GROUP BY o.category, o.product_id, p.product_name
),
ranked AS (
    SELECT
        *,
        rank() OVER (PARTITION BY category ORDER BY completed_revenue DESC) AS category_rank
    FROM product_revenue
)
SELECT
    category, category_rank, product_id, product_name, units_sold, completed_revenue,
    '${ds}' AS ds
FROM ranked
WHERE category_rank <= 3
