-- Staging view (not written to disk): parse every raw order and decide whether it is
-- valid. A row gets exactly one reject_reason, or NULL when it is good.
--
-- Duplicate handling: among rows sharing an order_id, rows that are otherwise valid
-- rank first, so a bad copy can never knock out the good one.
WITH parsed AS (
    SELECT
        nullif(trim(o.order_id), '')              AS order_id,
        try_cast(trim(o.customer_id) AS INT)      AS customer_id,
        try_cast(trim(o.product_id) AS INT)       AS product_id,
        try_cast(trim(o.quantity) AS INT)         AS quantity,
        try_to_timestamp(trim(o.order_ts))        AS order_ts,
        lower(trim(o.status))                     AS status,
        o.quantity                                AS raw_quantity,
        o._source_file                            AS source_file
    FROM bronze_orders o
),
checked AS (
    SELECT
        p.*,
        CASE
            WHEN p.order_id IS NULL                                         THEN 'missing_order_id'
            WHEN p.customer_id IS NULL                                      THEN 'missing_customer_id'
            WHEN p.product_id IS NULL                                       THEN 'missing_product_id'
            WHEN p.quantity IS NULL                                         THEN 'non_numeric_quantity'
            WHEN p.quantity <= 0                                            THEN 'non_positive_quantity'
            WHEN p.order_ts IS NULL                                         THEN 'invalid_timestamp'
            WHEN p.status NOT IN ('completed','pending','cancelled','refunded')
                                                                            THEN 'invalid_status'
            WHEN c.customer_id IS NULL                                      THEN 'unknown_customer'
            WHEN pr.product_id IS NULL                                      THEN 'unknown_product'
        END AS base_reason
    FROM parsed p
    LEFT JOIN silver_customers c  ON c.customer_id = p.customer_id
    LEFT JOIN silver_products  pr ON pr.product_id = p.product_id
),
ranked AS (
    SELECT
        checked.*,
        row_number() OVER (
            PARTITION BY order_id
            ORDER BY (base_reason IS NOT NULL), order_ts
        ) AS rn
    FROM checked
)
SELECT
    order_id, customer_id, product_id, quantity, order_ts, status, raw_quantity, source_file,
    CASE
        WHEN base_reason IS NOT NULL                 THEN base_reason
        WHEN order_id IS NOT NULL AND rn > 1         THEN 'duplicate_order_id'
    END AS reject_reason
FROM ranked
