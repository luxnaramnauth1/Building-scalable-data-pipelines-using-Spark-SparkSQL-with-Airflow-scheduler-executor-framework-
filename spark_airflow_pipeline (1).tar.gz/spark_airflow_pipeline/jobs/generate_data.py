"""Job 1 - generate synthetic raw CSV files for one run date.

Stands in for an upstream system dropping files into a landing zone. The output
is deterministic per ds (seeded), and deliberately contains a few bad rows so the
cleaning and data-quality steps have something real to do:

* duplicate order_ids          * missing customer_id
* non-positive quantities      * non-numeric quantity
* unknown customer / product   * invalid status values
"""
from __future__ import annotations

import csv
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pipeline.config import Paths, validate_ds  # noqa: E402

COUNTRIES = ["US", "GB", "DE", "FR", "IN", "MU", "BR", "JP"]
CATEGORIES = {
    "electronics": ["Headphones", "Webcam", "Keyboard", "Mouse", "USB Hub", "Monitor"],
    "home": ["Desk Lamp", "Mug", "Blanket", "Plant Pot", "Clock"],
    "books": ["Data Engineering Handbook", "SQL Cookbook", "Spark Guide", "Python Notes"],
    "sports": ["Yoga Mat", "Water Bottle", "Dumbbell", "Skipping Rope"],
}
STATUSES = ["completed"] * 8 + ["pending", "cancelled", "refunded"]

N_CUSTOMERS = 200
N_ORDERS = 1000


def _write_csv(path: Path, header: list[str], rows: list[list]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(header)
        writer.writerows(rows)


def _customers(rng: random.Random) -> list[list]:
    rows = []
    for cid in range(1, N_CUSTOMERS + 1):
        signup = datetime(2024, 1, 1) + timedelta(days=rng.randint(0, 700))
        rows.append([cid, f"Customer {cid}", f"customer{cid}@example.com",
                     rng.choice(COUNTRIES), signup.date().isoformat()])
    return rows


def _products(rng: random.Random) -> list[list]:
    rows, pid = [], 1
    for category, names in CATEGORIES.items():
        for name in names:
            rows.append([pid, name, category, round(rng.uniform(5, 250), 2)])
            pid += 1
    return rows


def _orders(rng: random.Random, ds: str, n_products: int) -> list[list]:
    day = datetime.strptime(ds, "%Y-%m-%d")
    compact = ds.replace("-", "")
    rows = []
    for i in range(1, N_ORDERS + 1):
        ts = day + timedelta(seconds=rng.randint(0, 86399))
        rows.append([
            f"{compact}-{i:05d}",
            rng.randint(1, N_CUSTOMERS),
            rng.randint(1, n_products),
            rng.randint(1, 5),
            ts.strftime("%Y-%m-%d %H:%M:%S"),
            rng.choice(STATUSES),
        ])

    # Inject defects (positions are random but reproducible).
    def pick(k: int) -> list[int]:
        return rng.sample(range(len(rows)), k)

    for idx in pick(20):                       # duplicates of existing orders
        rows.append(list(rows[idx]))
    for idx in pick(10):                       # missing customer_id
        rows[idx][1] = ""
    for idx in pick(10):                       # negative / zero quantity
        rows[idx][3] = rng.choice([0, -1, -3])
    for idx in pick(5):                        # non-numeric quantity
        rows[idx][3] = "abc"
    for idx in pick(8):                        # customer that does not exist
        rows[idx][1] = N_CUSTOMERS + 999
    for idx in pick(6):                        # product that does not exist
        rows[idx][2] = n_products + 999
    for idx in pick(6):                        # invalid status
        rows[idx][5] = "weird"
    rng.shuffle(rows)
    return rows


def run(ds: str, paths: Paths) -> dict[str, str]:
    validate_ds(ds)
    rng = random.Random(f"sales-{ds}")
    customers = _customers(rng)
    products = _products(rng)
    orders = _orders(rng, ds, len(products))

    files = {
        "customers": (["customer_id", "name", "email", "country", "signup_date"], customers),
        "products": (["product_id", "product_name", "category", "unit_price"], products),
        "orders": (["order_id", "customer_id", "product_id", "quantity", "order_ts", "status"], orders),
    }
    written = {}
    for entity, (header, rows) in files.items():
        target = paths.raw_file(entity, ds)
        _write_csv(target, header, rows)
        written[entity] = str(target)
        print(f"[generate_data] wrote {len(rows):>5} rows -> {target}")
    return written


def main() -> None:
    from pipeline.cli import job_parser

    args = job_parser("Generate synthetic raw CSV files").parse_args()
    run(args.ds, Paths(args.data_dir))


if __name__ == "__main__":
    main()
