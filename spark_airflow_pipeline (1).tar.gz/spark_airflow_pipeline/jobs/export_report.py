"""Job 5 - export the gold tables as single, named CSV files plus a JSON summary.

Spark writes a directory of part files; consumers usually want one CSV, so each
table is coalesced to one partition and the part file is renamed.
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pipeline.config import Paths, validate_ds  # noqa: E402
from pipeline.spark_utils import get_spark, read_partition  # noqa: E402

REPORTS = {
    "daily_sales": ("gold_daily_sales", "order_date, category, country"),
    "customer_ltv": ("gold_customer_ltv", "revenue_rank, customer_id"),
    "top_products": ("gold_top_products", "category, category_rank, product_id"),
    "rejected_orders": ("silver_orders_rejected", "reject_reason, order_id"),
}


def _write_single_csv(df, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as tmp:
        tmp_out = Path(tmp) / "out"
        df.coalesce(1).write.option("header", True).csv(str(tmp_out))
        parts = sorted(tmp_out.glob("part-*.csv"))
        if not parts:
            raise RuntimeError(f"Spark produced no CSV part file for {target.name}")
        shutil.move(str(parts[0]), str(target))


def run(ds: str, paths: Paths) -> dict[str, str]:
    validate_ds(ds)
    spark = get_spark("export_report")
    out_dir = paths.reports_dir(ds)
    layer_of = {"gold_daily_sales": "gold", "gold_customer_ltv": "gold",
                "gold_top_products": "gold", "silver_orders_rejected": "silver"}

    written: dict[str, str] = {}
    summary: dict[str, object] = {"ds": ds, "reports": {}}
    for report, (table, order_by) in REPORTS.items():
        df = read_partition(spark, paths.layer(layer_of[table], table), ds).drop("ds")
        df.createOrReplaceTempView("export_tmp")
        ordered = spark.sql(f"SELECT * FROM export_tmp ORDER BY {order_by}")
        target = out_dir / f"{report}.csv"
        _write_single_csv(ordered, target)
        written[report] = str(target)
        summary["reports"][report] = {"rows": ordered.count(), "file": target.name}
        print(f"[export_report] {report:<16} {summary['reports'][report]['rows']:>6} rows -> {target}")

    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    written["summary"] = str(out_dir / "summary.json")
    return written


def main() -> None:
    from pipeline.cli import job_parser

    args = job_parser("Export gold tables to CSV reports").parse_args()
    run(args.ds, Paths(args.data_dir))


if __name__ == "__main__":
    main()
