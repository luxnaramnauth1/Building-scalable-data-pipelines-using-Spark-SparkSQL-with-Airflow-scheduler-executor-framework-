"""Utility - read and inspect any file or table in the lake (csv, parquet, json, text).

Examples
--------
  python jobs/read_file.py data/raw/orders/ds=2026-10-01/orders.csv
  python jobs/read_file.py data/gold/gold_daily_sales --limit 5
  python jobs/read_file.py data/silver/silver_orders_clean --schema
  python jobs/read_file.py data/gold/gold_customer_ltv \
      --sql "SELECT ltv_tier, count(*) n FROM t GROUP BY ltv_tier ORDER BY n DESC"

The data is exposed to --sql as a temp view called ``t``.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pyspark.sql import DataFrame, SparkSession  # noqa: E402

from pipeline.spark_utils import get_spark  # noqa: E402


def detect_format(path: Path) -> str:
    """Guess csv / parquet / json / text from the extension, or from a directory's contents."""
    suffix = path.suffix.lower()
    if path.is_dir():
        if any(path.rglob("*.parquet")):
            return "parquet"
        if any(path.rglob("*.csv")):
            return "csv"
        if any(path.rglob("*.json")):
            return "json"
        raise ValueError(f"Cannot detect a format for directory {path}")
    return {
        ".csv": "csv", ".tsv": "csv", ".parquet": "parquet",
        ".json": "json", ".jsonl": "json", ".ndjson": "json",
    }.get(suffix, "text")


def read_any(spark: SparkSession, path: str | Path, fmt: str = "auto") -> DataFrame:
    """Load a file or directory into a DataFrame; partition dirs (ds=...) become columns."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"No such file or directory: {p}")
    fmt = detect_format(p) if fmt == "auto" else fmt

    if fmt == "csv":
        sep = "\t" if p.suffix.lower() == ".tsv" else ","
        return spark.read.option("header", True).option("inferSchema", True).option("sep", sep).csv(str(p))
    if fmt == "parquet":
        return spark.read.parquet(str(p))
    if fmt == "json":
        return spark.read.json(str(p))
    return spark.read.text(str(p))


def main() -> None:
    parser = argparse.ArgumentParser(description="Read and inspect a file or lake table")
    parser.add_argument("path")
    parser.add_argument("--format", default="auto", choices=["auto", "csv", "parquet", "json", "text"])
    parser.add_argument("--limit", type=int, default=20, help="rows to show (default 20)")
    parser.add_argument("--schema", action="store_true", help="print the schema")
    parser.add_argument("--sql", help="run a SparkSQL query against the data (view name: t)")
    args = parser.parse_args()

    spark = get_spark("read_file")
    df = read_any(spark, args.path, args.format)

    if args.schema:
        df.printSchema()

    if args.sql:
        df.createOrReplaceTempView("t")
        df = spark.sql(args.sql)
    else:
        print(f"rows: {df.count()}")

    df.show(args.limit, truncate=False)


if __name__ == "__main__":
    main()
