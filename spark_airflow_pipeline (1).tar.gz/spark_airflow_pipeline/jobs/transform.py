"""Job 3 - Bronze -> Silver -> Gold using SparkSQL files from ./sql.

Each step is one single-statement .sql file. The runner:
  1. executes the SQL (with ${ds} substituted),
  2. writes the result to the lake as parquet partitioned by ds (idempotent), and
  3. registers the result as a temp view so later steps can SELECT from it by name.

Steps with ``layer=None`` are staging views only and are never written to disk.
For every written table a ``<name>_all`` view (all partitions <= ds) is also
registered, which is what cumulative metrics such as customer LTV read.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pipeline.config import ENTITIES, Paths, validate_ds  # noqa: E402
from pipeline.spark_utils import (  # noqa: E402
    get_spark,
    read_partition,
    run_sql_file,
    write_partition,
)


@dataclass(frozen=True)
class Step:
    name: str               # table / view name referenced by later SQL
    sql_file: str
    layer: str | None       # "silver", "gold", or None for a staging view


STEPS: tuple[Step, ...] = (
    Step("silver_customers",       "10_silver_customers.sql",       "silver"),
    Step("silver_products",        "11_silver_products.sql",        "silver"),
    Step("stg_orders_checked",     "12_stg_orders_checked.sql",     None),
    Step("silver_orders_clean",    "13_silver_orders_clean.sql",    "silver"),
    Step("silver_orders_rejected", "14_silver_orders_rejected.sql", "silver"),
    Step("gold_daily_sales",       "20_gold_daily_sales.sql",       "gold"),
    Step("gold_customer_ltv",      "21_gold_customer_ltv.sql",      "gold"),
    Step("gold_top_products",      "22_gold_top_products.sql",      "gold"),
)


def register_bronze_views(spark, paths: Paths, ds: str) -> None:
    for entity in ENTITIES:
        read_partition(spark, paths.bronze(entity), ds).createOrReplaceTempView(f"bronze_{entity}")


def register_lake_views(spark, paths: Paths, ds: str) -> None:
    """Register views over already-written silver/gold tables (used by quality checks)."""
    for step in STEPS:
        if step.layer is None:
            continue
        table_path = paths.layer(step.layer, step.name)
        read_partition(spark, table_path, ds).createOrReplaceTempView(step.name)
        read_partition(spark, table_path, ds, up_to=True).createOrReplaceTempView(f"{step.name}_all")


def run(ds: str, paths: Paths) -> dict[str, int]:
    validate_ds(ds)
    spark = get_spark("transform")
    register_bronze_views(spark, paths, ds)

    counts: dict[str, int] = {}
    for step in STEPS:
        df = run_sql_file(spark, step.sql_file, ds=ds)

        if step.layer is None:
            df.createOrReplaceTempView(step.name)
            print(f"[transform] {step.name:<24} staging view")
            continue

        table_path = paths.layer(step.layer, step.name)
        write_partition(df, table_path)
        read_partition(spark, table_path, ds).createOrReplaceTempView(step.name)
        read_partition(spark, table_path, ds, up_to=True).createOrReplaceTempView(f"{step.name}_all")

        counts[step.name] = spark.table(step.name).count()
        print(f"[transform] {step.name:<24} {counts[step.name]:>6} rows -> {table_path}")

    return counts


def main() -> None:
    from pipeline.cli import job_parser

    args = job_parser("Transform bronze into silver and gold with SparkSQL").parse_args()
    run(args.ds, Paths(args.data_dir))


if __name__ == "__main__":
    main()
