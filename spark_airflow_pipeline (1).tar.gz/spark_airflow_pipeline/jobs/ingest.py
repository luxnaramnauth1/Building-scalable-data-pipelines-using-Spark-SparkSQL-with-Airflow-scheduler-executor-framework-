"""Job 2 - read the raw CSV files and land them in the Bronze layer.

Bronze keeps every column as a *string* (schema-on-read) and adds lineage
columns, so no row is ever lost at this stage. Typing, validation and
deduplication happen later in SparkSQL (jobs/transform.py).
"""
from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pyspark.sql import functions as F  # noqa: E402

from pipeline.config import ENTITIES, Paths, validate_ds  # noqa: E402
from pipeline.spark_utils import get_spark, write_partition  # noqa: E402


def run(ds: str, paths: Paths) -> dict[str, int]:
    validate_ds(ds)
    spark = get_spark("ingest")
    counts: dict[str, int] = {}

    for entity in ENTITIES:
        source = paths.raw_file(entity, ds)
        if not source.exists():
            raise FileNotFoundError(
                f"Raw file missing: {source}. Did the generate_data task run for ds={ds}?"
            )

        df = (
            spark.read.option("header", True)
            .option("inferSchema", False)       # everything stays string in bronze
            .option("mode", "PERMISSIVE")
            .option("multiLine", False)
            .csv(str(source))
            .withColumn("_source_file", F.col("_metadata.file_path"))
            .withColumn("_ingested_at", F.current_timestamp())
            .withColumn("ds", F.lit(ds))
        )
        write_partition(df, paths.bronze(entity))

        counts[entity] = spark.read.parquet(str(paths.bronze(entity))).where(f"ds = '{ds}'").count()
        print(f"[ingest] {entity:<10} {counts[entity]:>6} rows -> {paths.bronze(entity)}")

    return counts


def main() -> None:
    from pipeline.cli import job_parser

    args = job_parser("Ingest raw CSV into the bronze layer").parse_args()
    run(args.ds, Paths(args.data_dir))


if __name__ == "__main__":
    main()
