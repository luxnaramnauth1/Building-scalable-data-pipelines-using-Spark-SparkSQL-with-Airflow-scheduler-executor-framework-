"""Job 4 - data-quality gate. Fails the run (non-zero exit) if any check fails.

Because the process exits non-zero, Airflow marks the task failed and downstream
tasks (the report export) do not run - bad data never reaches consumers.

Set MAX_REJECT_RATE (default 0.10) to tune how many rejected orders are tolerated.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pipeline.config import Paths, validate_ds  # noqa: E402
from pipeline.spark_utils import get_spark  # noqa: E402


class DataQualityError(RuntimeError):
    pass


def _scalar(spark, query: str):
    return spark.sql(query).collect()[0][0]


def run(ds: str, paths: Paths) -> list[dict]:
    from jobs.transform import register_bronze_views, register_lake_views

    validate_ds(ds)
    spark = get_spark("quality_check")
    register_bronze_views(spark, paths, ds)
    register_lake_views(spark, paths, ds)

    max_reject_rate = float(os.environ.get("MAX_REJECT_RATE", "0.10"))

    bronze_orders = _scalar(spark, "SELECT count(*) FROM bronze_orders")
    clean = _scalar(spark, "SELECT count(*) FROM silver_orders_clean")
    rejected = _scalar(spark, "SELECT count(*) FROM silver_orders_rejected")

    checks = [
        ("bronze_has_rows", bronze_orders > 0, f"bronze_orders={bronze_orders}"),
        (
            "row_reconciliation",
            bronze_orders == clean + rejected,
            f"bronze={bronze_orders} clean={clean} rejected={rejected}",
        ),
        (
            "reject_rate_within_threshold",
            bronze_orders > 0 and rejected / bronze_orders <= max_reject_rate,
            f"rate={rejected / bronze_orders:.4f} max={max_reject_rate}" if bronze_orders else "no rows",
        ),
        (
            "clean_order_id_unique",
            _scalar(spark, "SELECT count(*) - count(DISTINCT order_id) FROM silver_orders_clean") == 0,
            "no duplicate order_id in silver_orders_clean",
        ),
        (
            "clean_no_null_keys",
            _scalar(
                spark,
                "SELECT count(*) FROM silver_orders_clean "
                "WHERE order_id IS NULL OR customer_id IS NULL OR product_id IS NULL",
            ) == 0,
            "no null keys in silver_orders_clean",
        ),
        (
            "clean_values_positive",
            _scalar(
                spark,
                "SELECT count(*) FROM silver_orders_clean WHERE quantity <= 0 OR revenue < 0",
            ) == 0,
            "quantity > 0 and revenue >= 0",
        ),
        (
            "gold_matches_silver_revenue",
            abs(
                float(_scalar(spark, "SELECT coalesce(sum(gross_revenue), 0) FROM gold_daily_sales"))
                - float(_scalar(spark, "SELECT coalesce(sum(revenue), 0) FROM silver_orders_clean"))
            ) < 0.01,
            "sum(gold_daily_sales.gross_revenue) == sum(silver_orders_clean.revenue)",
        ),
        (
            "ltv_has_rows",
            _scalar(spark, "SELECT count(*) FROM gold_customer_ltv") > 0,
            "gold_customer_ltv not empty",
        ),
    ]

    results = [{"check": n, "passed": bool(ok), "detail": d} for n, ok, d in checks]

    out_dir = paths.quality_dir(ds)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")

    for r in results:
        print(f"[quality_check] {'PASS' if r['passed'] else 'FAIL'}  {r['check']:<32} {r['detail']}")

    failed = [r["check"] for r in results if not r["passed"]]
    if failed:
        raise DataQualityError(f"Data quality checks failed for ds={ds}: {', '.join(failed)}")
    return results


def main() -> None:
    from pipeline.cli import job_parser

    args = job_parser("Run data-quality checks").parse_args()
    run(args.ds, Paths(args.data_dir))


if __name__ == "__main__":
    main()
