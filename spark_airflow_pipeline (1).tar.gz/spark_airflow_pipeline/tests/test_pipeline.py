"""End-to-end tests: run the real pipeline on a temp data lake and check the results."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from jobs import export_report, generate_data, ingest, quality_check, transform  # noqa: E402
from jobs.read_file import read_any  # noqa: E402
from pipeline.config import Paths, validate_ds  # noqa: E402
from pipeline.spark_utils import get_spark, render_sql  # noqa: E402
from run_pipeline import TASKS, date_range, run_for_date  # noqa: E402

DS1, DS2 = "2026-10-01", "2026-10-02"


@pytest.fixture(scope="module")
def spark():
    return get_spark("tests")


@pytest.fixture(scope="module")
def lake(tmp_path_factory):
    paths = Paths(tmp_path_factory.mktemp("lake"))
    for ds in (DS1, DS2):
        run_for_date(ds, paths, list(TASKS))
    return paths


def test_validate_ds_rejects_injection():
    assert validate_ds("2026-10-01") == "2026-10-01"
    for bad in ("2026-10-1", "2026-10-01'; DROP TABLE x;--", "", "yesterday"):
        with pytest.raises(ValueError):
            validate_ds(bad)


def test_date_range_inclusive_and_ordered():
    assert date_range("2026-10-30", "2026-11-02") == [
        "2026-10-30", "2026-10-31", "2026-11-01", "2026-11-02"]


def test_render_sql_substitutes_ds():
    assert "'2026-10-01'" in render_sql("10_silver_customers.sql", ds="2026-10-01")


def test_generate_data_is_deterministic(tmp_path):
    a, b = Paths(tmp_path / "a"), Paths(tmp_path / "b")
    generate_data.run(DS1, a)
    generate_data.run(DS1, b)
    assert a.raw_file("orders", DS1).read_text() == b.raw_file("orders", DS1).read_text()


def test_ingest_fails_clearly_when_raw_missing(tmp_path):
    with pytest.raises(FileNotFoundError, match="generate_data"):
        ingest.run(DS1, Paths(tmp_path))


def test_bronze_keeps_every_raw_row(lake, spark):
    raw_lines = sum(1 for _ in lake.raw_file("orders", DS1).open()) - 1  # minus header
    bronze = spark.read.parquet(str(lake.bronze("orders"))).where(f"ds = '{DS1}'").count()
    assert bronze == raw_lines


def test_every_order_is_clean_or_rejected(lake, spark):
    bronze = spark.read.parquet(str(lake.bronze("orders"))).where(f"ds = '{DS1}'").count()
    clean = spark.read.parquet(str(lake.silver("silver_orders_clean"))).where(f"ds = '{DS1}'").count()
    rejected = spark.read.parquet(str(lake.silver("silver_orders_rejected"))).where(f"ds = '{DS1}'").count()
    assert clean + rejected == bronze
    assert rejected > 0, "generator injects bad rows, so some must be rejected"


def test_all_injected_defect_types_are_caught(lake, spark):
    reasons = {
        r[0] for r in spark.read.parquet(str(lake.silver("silver_orders_rejected")))
        .select("reject_reason").distinct().collect()
    }
    assert {"duplicate_order_id", "missing_customer_id", "non_positive_quantity",
            "non_numeric_quantity", "unknown_customer", "unknown_product",
            "invalid_status"} <= reasons


def test_clean_orders_have_unique_ids(lake, spark):
    df = spark.read.parquet(str(lake.silver("silver_orders_clean")))
    assert df.count() == df.select("order_id").distinct().count()


def test_gold_revenue_matches_silver(lake, spark):
    silver = spark.read.parquet(str(lake.silver("silver_orders_clean"))).where(f"ds = '{DS1}'")
    gold = spark.read.parquet(str(lake.gold("gold_daily_sales"))).where(f"ds = '{DS1}'")
    s = float(silver.agg({"revenue": "sum"}).collect()[0][0])
    g = float(gold.agg({"gross_revenue": "sum"}).collect()[0][0])
    assert abs(s - g) < 0.01


def test_ltv_is_cumulative_across_days(lake, spark):
    ltv = spark.read.parquet(str(lake.gold("gold_customer_ltv")))
    orders = lambda ds: ltv.where(f"ds = '{ds}'").agg({"lifetime_orders": "sum"}).collect()[0][0]
    assert orders(DS2) > orders(DS1)


def test_transform_is_idempotent(lake, spark):
    before = spark.read.parquet(str(lake.silver("silver_orders_clean"))).count()
    transform.run(DS1, lake)
    transform.run(DS1, lake)
    after = spark.read.parquet(str(lake.silver("silver_orders_clean"))).count()
    assert before == after


def test_quality_results_written_and_passing(lake):
    results = json.loads((lake.quality_dir(DS1) / "results.json").read_text())
    assert results and all(r["passed"] for r in results)


def test_quality_gate_fails_when_threshold_too_strict(lake, monkeypatch):
    monkeypatch.setenv("MAX_REJECT_RATE", "0.0001")
    with pytest.raises(quality_check.DataQualityError, match="reject_rate_within_threshold"):
        quality_check.run(DS1, lake)


def test_reports_exported_as_single_csv_files(lake):
    out = lake.reports_dir(DS1)
    for name in ("daily_sales", "customer_ltv", "top_products", "rejected_orders"):
        assert (out / f"{name}.csv").is_file()
    summary = json.loads((out / "summary.json").read_text())
    assert summary["ds"] == DS1 and summary["reports"]["daily_sales"]["rows"] > 0


def test_read_file_handles_csv_parquet_and_partitioned_dirs(lake, spark):
    csv_df = read_any(spark, lake.raw_file("orders", DS1))
    assert "order_id" in csv_df.columns
    pq_df = read_any(spark, lake.gold("gold_daily_sales"))
    assert "ds" in pq_df.columns and pq_df.count() > 0
    with pytest.raises(FileNotFoundError):
        read_any(spark, lake.base / "nope.csv")
