"""Airflow DAG: daily sales pipeline (generate -> ingest -> transform -> quality -> export).

Each task is a BashOperator that runs one job for the logical date (``{{ ds }}``), so:
  * a failed task can be cleared and re-run on its own,
  * jobs are idempotent (dynamic partition overwrite), so retries and backfills are safe,
  * the same job files run under ``python`` or ``spark-submit``.

Environment variables (set on the Airflow worker):
  PIPELINE_PROJECT_DIR   project root (default: the folder above dags/)
  PIPELINE_DATA_DIR      data lake root (default: <project>/data)
  USE_SPARK_SUBMIT       "1" to run jobs through spark-submit instead of python
  SPARK_MASTER           e.g. spark://spark-master:7077 or yarn (default local[2])
  SPARK_SUBMIT_ARGS      extra spark-submit flags, e.g. "--executor-memory 4g"
  MAX_REJECT_RATE        quality gate threshold (default 0.10)
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path

from airflow import DAG

try:  # Airflow 3
    from airflow.providers.standard.operators.bash import BashOperator
except ImportError:  # Airflow 2.x
    from airflow.operators.bash import BashOperator

PROJECT_DIR = os.environ.get("PIPELINE_PROJECT_DIR", str(Path(__file__).resolve().parents[1]))

if os.environ.get("USE_SPARK_SUBMIT") == "1":
    RUNNER = (
        "spark-submit --master ${SPARK_MASTER:-local[2]} ${SPARK_SUBMIT_ARGS:-}"
    )
else:
    RUNNER = "python"


def job_command(job: str) -> str:
    """Shell command for one job. {{ ds }} is rendered by Airflow's Jinja templating."""
    return f"cd {PROJECT_DIR} && {RUNNER} jobs/{job}.py --ds {{{{ ds }}}}"


default_args = {
    "owner": "data-engineering",
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "retry_exponential_backoff": True,
    "execution_timeout": timedelta(hours=1),
}

with DAG(
    dag_id="sales_pipeline",
    description="Spark SQL medallion pipeline: raw CSV -> bronze -> silver -> gold -> reports",
    start_date=datetime(2026, 10, 1),
    schedule="@daily",
    catchup=False,          # set True to backfill automatically from start_date
    max_active_runs=1,      # runs in date order; partitions never collide
    default_args=default_args,
    tags=["spark", "sparksql", "etl"],
) as dag:
    generate_data = BashOperator(task_id="generate_data", bash_command=job_command("generate_data"))
    ingest = BashOperator(task_id="ingest", bash_command=job_command("ingest"))
    transform = BashOperator(task_id="transform", bash_command=job_command("transform"))
    quality_check = BashOperator(task_id="quality_check", bash_command=job_command("quality_check"))
    export_report = BashOperator(task_id="export_report", bash_command=job_command("export_report"))

    generate_data >> ingest >> transform >> quality_check >> export_report
